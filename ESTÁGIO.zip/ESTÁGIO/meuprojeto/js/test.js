function validarFormulario() {

    document.getElementById('erroNome').textContent = "";
    document.getElementById('erroEmail').textContent = "";
    document.getElementById('erroIdade').textContent = "";

    let valido = true;


    const nome = document.getElementById('nome').value.trim();
    const email = document.getElementById('email').value.trim();
    const idade = document.getElementById('idade').value.trim();


    if (nome === "") {
        document.getElementById('erroNome').textContent = "O campo Nome é obrigatório.";
        document.getElementById('nome').focus();
        document.querySelector('label[for="nome"] .asterisco').style.color = "var(--cor-erro)";
        valido = false;
    }


    if (email === "") {
        document.getElementById('erroEmail').textContent = "O campo Email é obrigatório.";
        document.querySelector('label[for="email"] .asterisco').style.color = "var(--cor-erro)";
        valido = false;
    } else if (!email.includes('@')) {
        document.getElementById('erroEmail').textContent = "Por favor, insira um email válido.";
        valido = false;
    }


    if (idade === "") {
        document.getElementById('erroIdade').textContent = "O campo Idade é obrigatório.";
        document.querySelector('label[for="idade"] .asterisco').style.color = "var(--cor-erro)";
        valido = false;
    } else if (parseInt(idade) < 18) {
        document.getElementById('erroIdade').textContent = "Você deve ter 18 anos ou mais.";
        valido = false;
    }


    if (valido) {
        sessionStorage.setItem("nome", nome);
        sessionStorage.setItem("email", email);
        sessionStorage.setItem("idade", idade);
        alert("Cadastro realizado com sucesso!");
        window.location.href = "perfil.html";
    }
}

function alternarTema() {
    const body = document.body;
    const botao = document.querySelector('button[onclick="alternarTema()"]');
    body.classList.toggle('tema-escuro');
    body.classList.toggle('tema-claro');

    if (body.classList.contains('tema-escuro')) {
        botao.textContent = "Modo Claro";
    } else {
        botao.textContent = "Modo Escuro";
    }
}
