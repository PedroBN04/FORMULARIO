document.addEventListener("DOMContentLoaded", () => {
    const nome = sessionStorage.getItem("nome");
    const email = sessionStorage.getItem("email");
    const idade = sessionStorage.getItem("idade");


    if (nome && email && idade) {
        document.getElementById("perfilNome").textContent = nome;
        document.getElementById("perfilEmail").textContent = email;
        document.getElementById("perfilIdade").textContent = idade;
    } else {
        alert("Nenhum usuário está logado. Redirecionando para o formulário.");
        window.location.href = "form.html";
    }
});


function sair() {
    sessionStorage.clear();
    alert("Você saiu do perfil.");
    window.location.href = "form.html";
}
